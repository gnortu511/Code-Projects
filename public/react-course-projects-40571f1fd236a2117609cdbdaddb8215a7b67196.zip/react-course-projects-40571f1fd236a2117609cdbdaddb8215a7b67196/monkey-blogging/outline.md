<!-- 1. Cài đặt Project Boilerplate Monkey Blogging
2. Thiết lập Firebase
3. Thiết lập Routes
4. Viết auth-context để lưu trữ thông tin User
5. Code trang SignUp - UI
6. Code trang SignUp - React hook form
7. Code trang SignUp - Authentication với Firebase
8. Sử dụng PropTypes và comment params cho component
9. Login UI
10. Header UI
11. Homepage UI
12. Details UI
13. Dashboard UI
14. Checkbox, radio, toggle
-->

15. Add new post: overview, upload image, delete image, toggle hot, find category
16. Add new category
17. Add new user
18. Update post: ckeditor
19. Update category
20. Update user
21. Display data
22. Pagination data
23. Filter data
