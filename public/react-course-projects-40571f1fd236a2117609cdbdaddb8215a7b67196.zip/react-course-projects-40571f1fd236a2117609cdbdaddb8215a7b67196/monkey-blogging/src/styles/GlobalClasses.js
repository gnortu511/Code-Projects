import { css } from "styled-components";

export const GlobalClasses = css``;
