const { default: Pagination } = require("./Pagination");

export { Pagination };
