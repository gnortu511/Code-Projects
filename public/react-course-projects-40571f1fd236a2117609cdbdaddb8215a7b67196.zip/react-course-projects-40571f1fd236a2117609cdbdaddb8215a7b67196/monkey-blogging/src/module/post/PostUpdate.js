import React from "react";

const PostUpdate = () => {
  return <div></div>;
};

export default PostUpdate;
